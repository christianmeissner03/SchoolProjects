/*
Project: Chapter 15 Java II Programming Exercise 4
Date: 1/6/20
Name: Christian Meissner
Purpose: Create a simple program that simulates a calculator (additon, subtraction, multiplication, division)
 */

// importing application pane, labels, buttons, and text fields for our stage
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class Calculator extends Application {
    // instances for the textfield variables
    private TextField num1 = new TextField();
    private TextField num2 = new TextField();
    private TextField result = new TextField();
    
    
    @Override
    public void start(Stage primaryStage) {
        
        // setting the width of the textfields
        num1.setMinWidth(50);
        num2.setMinWidth(50);
        result.setMinWidth(50);
        
        // creating the buttons then setting their sizes
        Button add = new Button("Add");
        add.setMinWidth(75);
        Button sub = new Button("Subtract");
        sub.setMinWidth(75);
        Button mul = new Button("Multiply");
        mul.setMinWidth(75);
        Button div = new Button("Divide");
        div.setMinWidth(75);
       
        // creating the gridpane and setting its gaps
        GridPane pane = new GridPane();
        pane.setHgap(5);
        pane.setVgap(5);
        
        // adding the labels and textfields to the pane
        pane.add(new Label("Number 1:"), 0, 0);
        pane.add(num1, 1, 0);
        pane.add(new Label("Number 2:"), 2, 0);
        pane.add(num2, 3, 0);
        pane.add(new Label("Result:"), 4, 0);
        pane.add(result, 5, 0);
        
        // adding the buttons and giving them actions
        pane.add(add, 0, 4);
        add.setOnAction(e -> add());
        pane.add(sub, 2, 4);
        sub.setOnAction(e -> sub());
        pane.add(mul, 4, 4);
        mul.setOnAction(e -> mul());
        pane.add(div, 6, 4);
        div.setOnAction(e -> div());
        
        
        // setting up the scene and stage then displaying it
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Exercise15_04");
        primaryStage.setScene(scene);
        primaryStage.setWidth(500);
        primaryStage.setHeight(150);
        primaryStage.show();
    }
    
    // 4 void methods for the calculator (each one takes both the numbers entered and does the following math
    // then setting the answer into the result textfield
    private void add() {
        double sum = Double.parseDouble(num1.getText()) + Double.parseDouble(num2.getText());
        String s = Double.toString(sum);
        result.setText(s);
    }
    
    private void sub() {
        double difference = Double.parseDouble(num1.getText()) - Double.parseDouble(num2.getText());
        String s = Double.toString(difference);
        result.setText(s);
    }
    
    private void mul() {
        double product = Double.parseDouble(num1.getText()) * Double.parseDouble(num2.getText());
        String s = Double.toString(product);
        result.setText(s);
    }
    
    private void div() {
        double quotient = Double.parseDouble(num1.getText()) / Double.parseDouble(num2.getText());
        // if statement to return Error if the number is being divided by zero
        if (num2.getText().equals("0")) {
            result.setText("Error");
        }
        else {
            String s = Double.toString(quotient);
            result.setText(s);
        }
        
    }
    
    // launching the application
    public static void main(String[] args) {
        Application.launch(args);
    }
    
}

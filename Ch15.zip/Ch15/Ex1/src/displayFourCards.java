/*
Project: Chapter 15 Java II Programming Exercise 1
Name: Christian Meissner
Date: 12/11/19
Purpose: Display 4 random cards in a scene from a stack of 52
 */

// importing everthing to add to the GUI/application and random for random numbers
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Random;

public class displayFourCards extends Application {
    @Override
    
    public void start(Stage primaryStage) {
        // adding a pane setting its size and its alignment
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(5, 5, 5, 5));
        pane.setHgap(5);
        pane.setVgap(5);
        
        // adding the refresh button making it work then setting the size and position
        Button refresh = new Button("Refresh");
        refresh.setOnAction(e -> displayImage(pane));
        pane.add(refresh, 2, 1);
        refresh.setMinWidth(100);
        refresh.setMinHeight(2);
        
        
        
        // adding scene then setting title and size of the stage
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Exercise15_01");
        primaryStage.setScene(scene);
        primaryStage.setWidth(650);
        primaryStage.setHeight(300);
        primaryStage.show();
        displayImage(pane);
    }
    
    // display image method to get the four random cards
    public void displayImage(GridPane pane) {
        // getting four random integers between 1-52
        Random ran = new Random();
        int random1 = ran.nextInt(52) + 1;
        int random2 = ran.nextInt(52) + 1;
        int random3 = ran.nextInt(52) + 1;
        int random4 = ran.nextInt(52) + 1;
        
        // changing the integers into strings
        String randomCardOne = Integer.toString(random1);
        String randomCardTwo = Integer.toString(random2);
        String randomCardThree = Integer.toString(random3);
        String randomCardFour = Integer.toString(random4);
        
        
        
        // adding the random cards images to the imageviews with appropriate sizing
        Image cardOne = new Image("cards/" + randomCardOne + ".png", 200, 200, true, true);
        pane.add(new ImageView(cardOne), 0, 0);
        
        Image cardTwo = new Image("cards/" + randomCardTwo + ".png", 200, 200, true, true);
        pane.add(new ImageView(cardTwo), 1, 0);
        
        Image cardThree = new Image("cards/" + randomCardThree + ".png", 200, 200, true, true);
        pane.add(new ImageView(cardThree), 3, 0);

        Image cardFour = new Image("cards/" + randomCardFour + ".png", 200, 200, true, true);
        pane.add(new ImageView(cardFour), 4, 0);
        
        }
    
    // launching the application
    public static void main(String[] args) {
        Application.launch(args);
    }
    
}
